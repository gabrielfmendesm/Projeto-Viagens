package br.Insper.Projeto.Viagem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/viagens")
public class ViagemController {

    @Autowired
    private ViagemService viagemService;

    // Método para criar uma viagem
    @PostMapping
    public ResponseEntity<?> criarViagem(@RequestBody Viagem viagem) {
        // Tenta criar a viagem
        try {
            // Se a viagem for criada com sucesso, retorna a viagem
            return ResponseEntity.ok(viagemService.criarViagem(viagem));
            // Se ocorrer uma exceção, retorna uma resposta com status 400 e a mensagem da exceção
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Método para listar todas as viagens
    @GetMapping
    public ResponseEntity<List<Viagem>> listarViagens() {
        // Retorna todas as viagens
        return ResponseEntity.ok(viagemService.listarViagens());
    }

    // Método para finalizar uma viagem
    @PutMapping("/{id}/finalizar")
    public ResponseEntity<?> finalizarViagem(@PathVariable Integer id) {
        // Tenta finalizar a viagem
        try {
            // Se a viagem for finalizada com sucesso, retorna a viagem
            return ResponseEntity.ok(viagemService.finalizarViagem(id));
            // Se ocorrer uma exceção, retorna uma resposta com status 400 e a mensagem da exceção
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // Método para listar todas as viagens de um motorista
    @GetMapping("/motorista/{motoristaId}")
    public ResponseEntity<List<Viagem>> listarViagensPorMotorista(@PathVariable Integer motoristaId) {
        // Retorna todas as viagens de um motorista
        return ResponseEntity.ok(viagemService.listarViagensPorMotorista(motoristaId));
    }
}
