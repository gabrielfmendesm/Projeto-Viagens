package br.Insper.Projeto.Viagem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;
import org.json.JSONObject;

import java.util.List;

@Service
public class ViagemService {

    private final ViagemRepository viagemRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public ViagemService(ViagemRepository viagemRepository, RestTemplate restTemplate) {
        this.viagemRepository = viagemRepository;
        this.restTemplate = restTemplate;
    }

    // Método para listar todas as viagens
    public List<Viagem> listarViagens() {

        // Retorna todas as viagens
        return viagemRepository.findAll();
    }

    public Viagem criarViagem(Viagem viagem) {
        // Verifica se a origem está presente
        if (viagem.getOrigem() == null || viagem.getOrigem().isEmpty()) {
            // Se não estiver presente, lança uma exceção
            throw new IllegalArgumentException("Origem é obrigatória");
        }

        // Verifica se o destino está presente
        if (viagem.getDestino() == null || viagem.getDestino().isEmpty()) {
            // Se não estiver presente, lança uma exceção
            throw new IllegalArgumentException("Destino é obrigatório");
        }

        // Tenta criar a viagem
        try {
            // Faz uma requisição GET para receber um motorista disponível
            ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080/motoristas/disponivel", String.class);

            // Analisa a resposta JSON para obter o ID do motorista
            JSONObject jsonObject = new JSONObject(response.getBody());
            Integer motoristaId = jsonObject.getInt("id");

            // Define o ID do motorista na viagem
            viagem.setMotoristaId(motoristaId);

            // Muda o status da viagem para CONFIRMADO
            viagem.setStatus("CONFIRMADO");

            // Cria um objeto HttpEntity com o novo status
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>("INDISPONIVEL", headers);

            // Muda o status do motorista para INDISPONIVEL
            String updateUrl = "http://localhost:8080/motoristas/status/" + viagem.getMotoristaId() + "/key/INDISPONIVEL";

            // Faz a requisição PUT para atualizar o status do motorista
            restTemplate.put(updateUrl, entity);

            // Atualiza a data de início da viagem
            viagem.setDataInicio(java.time.LocalDateTime.now());

            // Salva a viagem no banco de dados
            return viagemRepository.save(viagem);
        }
        // Se ocorrer uma exceção
        catch (Exception e) {
            // Muda o status da viagem para ERRO
            viagem.setStatus("ERRO");

            // Salva a viagem no banco de dados
            viagemRepository.save(viagem);

            // Lança uma exceção
            throw new RuntimeException("Viagem não pode ser criada");
        }
    }

    public Viagem finalizarViagem(Integer id) {
        // Busca a viagem pelo id
        Viagem viagem = viagemRepository.findById(id).orElseThrow(() -> new RuntimeException("Viagem não encontrada"));
        // Muda o status da viagem para FINALIZADO
        viagem.setStatus("FINALIZADO");

        // Cria um objeto HttpEntity com o novo status
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>("DISPONIVEL", headers);

        // Atualiza o status do motorista para DISPONIVEL
        String updateUrl = "http://localhost:8080/motoristas/status/" + viagem.getMotoristaId() + "/key/DISPONIVEL";

        // Faz a requisição PUT para atualizar o status do motorista
        restTemplate.put(updateUrl, entity);

        // Salva a viagem no banco de dados com o status FINALIZADO
        return viagemRepository.save(viagem);
    }

    // Método para listar todas as viagens de um motorista
    public List<Viagem> listarViagensPorMotorista(Integer motoristaId) {
        // Retorna todas as viagens de um motorista
        return viagemRepository.findAllByMotoristaId(motoristaId);
    }
}
