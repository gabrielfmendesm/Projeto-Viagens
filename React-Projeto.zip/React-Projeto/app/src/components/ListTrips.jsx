import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/styles.css';

function ListTrips() {
    const [trips, setTrips] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchTrips = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/viagens');
                setTrips(response.data);
            } catch (error) {
                setError(`Erro ao buscar viagens: ${error.message}`);
            }
        };
        fetchTrips();
    }, []);

    return (
        <div className="container">
            <h2>Listar Viagens</h2>
            {error && <p>{error}</p>}
            <ul>
                {trips.map(trip => (
                    <li key={trip.id}>De: {trip.origem} Para: {trip.destino} - Status: {trip.status}</li>
                ))}
            </ul>
        </div>
    );
}

export default ListTrips;
