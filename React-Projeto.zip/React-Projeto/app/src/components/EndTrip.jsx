import React, { useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import '../styles/styles.css';

function EndTrip() {
    const { id } = useParams();
    const [status, setStatus] = useState('');

    const handleEndTrip = async () => {
        try {
            await axios.put(`http://localhost:8080/api/viagens/${id}/finalizar`);
            setStatus('Viagem finalizada com sucesso!');
        } catch (error) {
            setStatus(`Erro ao finalizar a viagem: ${error.message}`);
        }
    };

    return (
        <div className="container">
            <h2>Finalizar Viagem</h2>
            <button onClick={handleEndTrip}>Finalizar Viagem</button>
            {status && <p>{status}</p>}
        </div>
    );
}

export default EndTrip;
