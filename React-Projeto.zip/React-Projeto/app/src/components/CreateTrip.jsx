import React, { useState } from 'react';
import axios from 'axios';
import '../styles/styles.css';

function CreateTrip() {
    const [trip, setTrip] = useState({
        origem: '',
        destino: '',
        dataInicio: '',
        horasViagem: 0,
        precoTotal: 0,
        motoristaId: 0
    });

    const handleChange = e => {
        setTrip({ ...trip, [e.target.name]: e.target.value });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8080/api/viagens', trip);
            alert('Viagem criada com sucesso!');
        } catch (error) {
            alert('Erro ao criar viagem: ' + error.response.data);
        }
    };

    return (
        <div className="container">
            <h2>Criar Viagem</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="origem" placeholder="Origem" onChange={handleChange} value={trip.origem} />
                <input type="text" name="destino" placeholder="Destino" onChange={handleChange} value={trip.destino} />
                <input type="text" name="dataInicio" placeholder="Data de Início" onChange={handleChange} value={trip.dataInicio} />
                <input type="number" name="horasViagem" placeholder="Horas da Viagem" onChange={handleChange} value={trip.horasViagem} />
                <input type="number" name="precoTotal" placeholder="Preço Total" onChange={handleChange} value={trip.precoTotal} />
                <input type="number" name="motoristaId" placeholder="ID do Motorista" onChange={handleChange} value={trip.motoristaId} />
                <button type="submit">Criar Viagem</button>
            </form>
        </div>
    );
}

export default CreateTrip;
