import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Navbar from './components/Navbar';
import CreateTrip from './components/CreateTrip';
import ListTrips from './components/ListTrips';
import EndTrip from './components/EndTrip';
import './styles/styles.css';

function App() {
    return (
        <Router>
            <div>
                <Navbar />
                <Switch>
                    <Route path="/create" component={CreateTrip} />
                    <Route path="/list" component={ListTrips} />
                    <Route path="/end/:id" component={EndTrip} />
                    <Route path="/" exact component={() => <h1>Welcome to the Trip Management System</h1>} />
                </Switch>
            </div>
        </Router>
    );
}

export default App;
