package br.Insper.Projeto.Viagem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Service
public class ViagemService {

    private final ViagemRepository viagemRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public ViagemService(ViagemRepository viagemRepository, RestTemplate restTemplate) {
        this.viagemRepository = viagemRepository;
        this.restTemplate = restTemplate;
    }

    public List<Viagem> listarViagens() {
        return viagemRepository.findAll();
    }

    public Viagem criarViagem(Viagem viagem) {
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080/motoristas/disponibilidade/" + viagem.getMotoristaId(), String.class);
        if (!response.getBody().equals("DISPONIVEL")) {
            throw new IllegalStateException("Motorista não está disponível");
        }
        viagem.setStatus("CONFIRMADO");

        // Cria um objeto HttpEntity com o novo status
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>("INDISPONIVEL", headers);

        // Atualiza o status do motorista para INDISPONIVEL
        String updateUrl = "http://localhost:8080/motoristas/status/" + viagem.getMotoristaId() + "/key/INDISPONIVEL";
        restTemplate.put(updateUrl, entity);
        return viagemRepository.save(viagem);
    }

    public Viagem finalizarViagem(Integer id) {
        Viagem viagem = viagemRepository.findById(id).orElseThrow(() -> new RuntimeException("Viagem não encontrada"));
        viagem.setStatus("FINALIZADO");

        // Cria um objeto HttpEntity com o novo status
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>("DISPONIVEL", headers);

        // Atualiza o status do motorista para DISPONIVEL
        String updateUrl = "http://localhost:8080/motoristas/status/" + viagem.getMotoristaId() + "/key/DISPONIVEL";
        restTemplate.put(updateUrl, entity);
        return viagemRepository.save(viagem);
    }

    public List<Viagem> listarViagensPorMotorista(Integer motoristaId) {
        return viagemRepository.findAllByMotoristaId(motoristaId);
    }
}
