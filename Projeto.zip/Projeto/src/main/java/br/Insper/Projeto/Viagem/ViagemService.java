package br.Insper.Projeto.Viagem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;

@Service
public class ViagemService {

    private final ViagemRepository viagemRepository;
    private final RestTemplate restTemplate;

    @Autowired
    public ViagemService(ViagemRepository viagemRepository, RestTemplate restTemplate) {
        this.viagemRepository = viagemRepository;
        this.restTemplate = restTemplate;
    }

    public List<Viagem> listarViagens() {
        // Retorna todas as viagens
        return viagemRepository.findAll();
    }

    public Viagem criarViagem(Viagem viagem) {
        // Verifica se o motorista está disponível (simulado por um mock endpoint)
        ResponseEntity<String> response = restTemplate.getForEntity("http://localhost:8080/api/motoristas/" + viagem.getMotoristaId() + "/disponibilidade", String.class);
        if (!response.getBody().equals("DISPONIVEL")) {
            throw new IllegalStateException("Motorista não está disponível");
        }
        viagem.setStatus("CONFIRMADO");
        return viagemRepository.save(viagem);
    }

    public Viagem finalizarViagem(Long id) {
        Viagem viagem = viagemRepository.findById(id).orElseThrow(() -> new RuntimeException("Viagem não encontrada"));
        viagem.setStatus("FINALIZADO");
        // Atualiza o status do motorista para disponível (simulado por um mock endpoint)
        restTemplate.put("http://localhost:8080/api/motoristas/" + viagem.getMotoristaId() + "/liberar", null);
        return viagemRepository.save(viagem);
    }

    public List<Viagem> listarViagensPorMotorista(Long motoristaId) {
        return viagemRepository.findAllByMotoristaId(motoristaId);
    }
}
