package br.Insper.Projeto.Viagem;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/viagens")
public class ViagemController {

    @Autowired
    private ViagemService viagemService;

    @PostMapping
    public ResponseEntity<?> criarViagem(@RequestBody Viagem viagem) {
        try {
            return ResponseEntity.ok(viagemService.criarViagem(viagem));
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<List<Viagem>> listarViagens() {
        return ResponseEntity.ok(viagemService.listarViagens());
    }

    @PutMapping("/{id}/finalizar")
    public ResponseEntity<?> finalizarViagem(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(viagemService.finalizarViagem(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/motorista/{motoristaId}")
    public ResponseEntity<List<Viagem>> listarViagensPorMotorista(@PathVariable Integer motoristaId) {
        return ResponseEntity.ok(viagemService.listarViagensPorMotorista(motoristaId));
    }
}
