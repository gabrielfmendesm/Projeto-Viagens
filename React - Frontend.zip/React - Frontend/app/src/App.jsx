import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import CreateTrip from './components/CreateTrip';
import ListTrips from './components/ListTrips';
import EndTrip from './components/EndTrip';
import './styles/styles.css';

function App() {
    return (
        <>
        <Navbar/>
        <Routes> {/* Substituímos Switch por Routes */}
            <Route path="/create" element={<CreateTrip />} /> {/* element ao invés de component */}
            <Route path="/list" element={<ListTrips />} />
            <Route path="/end" element={<EndTrip />} />
            <Route path="/" element={<h1>Welcome to the Trip Management System</h1>} exact /> {/* Rotas raiz precisam de exact */}
        </Routes>
        </>
    );
}

export default App;
