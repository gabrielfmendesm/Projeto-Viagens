import React, { useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import '../styles/styles.css';

function EndTrip() {
    const { id } = useParams();
    const [status, setStatus] = useState('');
    const [tripIdInput, setTripIdInput] = useState('');

    const handleEndTrip = async () => {
        try {
            // Send a PUT request to finalize the trip
            await axios.put(`http://localhost:8081/viagens/${tripIdInput}/finalizar`);
            setStatus('Viagem finalizada com sucesso!');
        } catch (error) {
            setStatus(`Erro ao finalizar a viagem: ${error.message}`);
        }
    };

    return (
        <div className="container">
            <h2>Finalizar Viagem</h2>
            {/* Input field for the trip ID */}
            <input
                type="text"
                placeholder="Insira o ID da viagem"
                value={tripIdInput}
                onChange={(e) => setTripIdInput(e.target.value)}
            />
            <button onClick={handleEndTrip}>Finalizar Viagem</button>
            {status && <p>{status}</p>}
        </div>
    );
}

export default EndTrip;
