import React, { useState } from 'react';
import '../styles/styles.css';

function CreateTrip() {
    const [trip, setTrip] = useState({
        origem: '',
        destino: '',
        dataInicio: '',
        horasViagem: 0,
        precoTotal: 0,
    });

    const handleChange = (e) => {
        setTrip({ ...trip, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await fetch('http://localhost:8081/viagens', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(trip),
            });

            if (!response.ok) {
                throw new Error('Erro ao criar viagem: ' + (await response.text()));
            }

            alert('Viagem criada com sucesso!');
        } catch (error) {
            alert(error.message);
        }
    };

    return (
        <div className="container">
            <h2>Criar Viagem</h2>
            <form onSubmit={handleSubmit}>
                <p>Origem</p>
                <input
                    type="text"
                    name="origem"
                    placeholder="Origem"
                    onChange={handleChange}
                    value={trip.origem}
                />
                <p>Destino</p>
                <input
                    type="text"
                    name="destino"
                    placeholder="Destino"
                    onChange={handleChange}
                    value={trip.destino}
                />
                <p>Horas da Viagem</p>
                <input
                    type="number"
                    name="horasViagem"
                    placeholder="Horas da Viagem"
                    onChange={handleChange}
                    value={trip.horasViagem}
                />
                <p>Preço Total</p>
                <input
                    type="number"
                    name="precoTotal"
                    placeholder="Preço Total"
                    onChange={handleChange}
                    value={trip.precoTotal}
                />
                <button type="submit">Criar Viagem</button>
            </form>
        </div>
    );
}

export default CreateTrip;
