import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../styles/styles.css';

function ListTrips() {
    const [trips, setTrips] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchTrips = async () => {
            try {
                const response = await fetch('http://localhost:8081/viagens'); // Make the GET request
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                const data = await response.json(); // Parse the response data
                setTrips(data); // Update the state with the fetched trips
            } catch (error) {
                setError(`Erro ao buscar viagens: ${error.message}`);
            }
        };
        fetchTrips();
    }, []);

    return (
        <div className="container">
            <h2>Listar Viagens</h2>
            {error && <p>{error}</p>}
            <ul>
                {trips.map(trip => (
                    <li key={trip.id}> ID da Viagem {trip.id} - De: {trip.origem} Para: {trip.destino} - Status: {trip.status} - Horas da Viagem: {trip.horasViagem} - Preço Total: {trip.precoTotal} - ID do Motorista: {trip.motoristaId}</li>
                ))}
            </ul>
        </div>
    );
}

export default ListTrips;
